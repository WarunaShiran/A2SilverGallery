package util;

public class commonConstants {
	/*constant for URL key of MySQL database*/
	public static final String URL= "jdbc:mysql://localhost:3306/a2silvergallery";
	
	/*constant for User Name key of MySQL database*/
	public static final String UN= "root";
	
	/*constant for Password key of MySQL database*/
	public static final String PWD= "1234";
	
	/*Constant used to generate an ID for Event*/
	public static final String Employee_ID_Prefix = "E100";
	
	/*Constant used to generate an ID for Event*/
	public static final String Bus_ID_Prefix = "B100";
	
	/*Constant used to generate an ID for Event*/
	public static final String Notification_ID_Prefix = "N100";
	
	public static final String Sale_ID_Prefix = "S100";
}
