package service;

import java.util.ArrayList;
import java.util.logging.Logger;

import model.Sales;
import model.Staff;
import model.StaffLogin;

public interface ISalesService {

	public static final Logger log  = Logger.getLogger(ISalesService.class.getName());
	
	
	/*
	 *Add Sales Into Staff Table 
	 */
	public void addSales(Sales sales);
	
	/*
	 * Display the list of Staff in the Database
	 * */
	public ArrayList<Sales> getSales();
	
	/*
	 * To get apurticular Staff by ID
	 * @input par StaffID
	 * @return Staff
	 * */
	public Sales getSalesByID(String SalesID);
	
	/*
	 * Update an existing staff Data
	 * @input par StaffID
	 * @return Staff
	 * */
	public Sales updateSales(String SalesID, Sales sales);
	
	/*
	 * Remove existing Staff
	 * @par StaffID
	 * */
	public void removeSales(String SalesID);
}
